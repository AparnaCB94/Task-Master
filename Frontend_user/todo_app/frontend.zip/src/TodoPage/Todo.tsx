// adding task to db
// import React, { useState, useRef, useEffect } from 'react';
// import { AiOutlineEdit, AiOutlineCheck, AiOutlineClose } from 'react-icons/ai';
// import { v4 as uuid } from 'uuid';
// import axios from 'axios';
// import { Link, useNavigate } from 'react-router-dom';
// import './todo.css';

// interface Todo {
//   id: string;
//   taskname: string;
//   completed: boolean;
//   color: string;
//   isEditing: boolean;
// }

// const getRandomColor = (): string => {
//   return '#ffeeba'; // or any color code you prefer
// };

// const App: React.FC = () => {
//   const navigate = useNavigate();
//   const [todos, setTodos] = useState<Todo[]>([]);
//   const [inputText, setInputText] = useState<string>('');

//   const textInputRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

//   const addTodo = async () => {
//     if (inputText.trim() !== '') {
//       const newTodo: Todo = {
//         id: uuid(),
//         taskname: inputText,
//         completed: false,
//         color: getRandomColor(), // Set the random color
//         isEditing: false,
//       };

//       try {
//         // Send the new todo to the MongoDB API
//         const response = await axios.post('http://localhost:4561/api/todo', newTodo);

//         if (response.status === 200) {
//           // Assuming your server returns a specific status for successful todo creation
//           setTodos((prevTodos) => [...prevTodos, newTodo]);
//           setInputText('');
//         } else {
//           // Handle unsuccessful todo creation (e.g., display an error message)
//           console.error('Error adding todo: Unexpected server response');
//         }
//       } catch (error) {
//         // Handle network or server errors
//         console.error('Error adding todo:', error);
//         // You can show an error message to the user or perform other error-handling tasks
//       }
//     }
//   };

//   const startEditing = (id: string) => {
//     setTodos((prevTodos) =>
//       prevTodos.map((todo) =>
//         todo.id === id ? { ...todo, isEditing: true } : todo
//       )
//     );
//   };

//   const updateTodo = (id: string) => {
//     setTodos((prevTodos) =>
//       prevTodos.map((todo) =>
//         todo.id === id ? { ...todo, isEditing: false } : todo
//       )
//     );
//   };

//   const deleteTodo = (id: string) => {
//     setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== id));
//   };

//   const signOut = () => {
//     // Remove the token from local storage and set Authorization header to null
//     localStorage.removeItem('token');
//     axios.defaults.headers.common['Authorization'] = null;

//     // Navigate to the home page or any desired location
//     navigate('/');
//   };

//   useEffect(() => {
//     todos.forEach((todo) => {
//       if (todo.isEditing && textInputRefs.current[todo.id]) {
//         textInputRefs.current[todo.id]?.focus();
//       }
//     });
//   }, [todos]);

//   return (
//     <div className="container mt-5">
//       <div className="d-flex justify-content-end mb-2">
//         <Link to="/" className="btn btn-link" onClick={signOut}>
//           Sign Out
//         </Link>
//       </div>
//       <h1 className="text-center mb-4">Todo App</h1>
//       <div className="mb-3 d-flex">
//         <input
//           type="text"
//           className="form-control flex-grow-1"
//           placeholder="Enter a task"
//           value={inputText}
//           onChange={(e) => setInputText(e.target.value)}
//         />
//         <button className="btn btn-primary ms-2" onClick={addTodo}>
//           Add Todo
//         </button>
//       </div>
//       <div className="d-flex flex-wrap">
//         {todos.map((todo) => (
//           <div
//             key={todo.id}
//             className={`p-3 m-2 sticky-note ${todo.completed ? 'text-muted' : 'text-dark'}`}
//           >
//             <div className="btn-group" style={{ position: 'absolute', bottom: '5px', right: '5px' }}>
//               <button
//                 className="btn btn-warning"
//                 onClick={() => startEditing(todo.id)}
//               >
//                 <AiOutlineEdit size={16} />
//               </button>
//               <button
//                 className="btn btn-success"
//                 onClick={() => updateTodo(todo.id)}
//               >
//                 <AiOutlineCheck size={16} />
//               </button>
//               <button
//                 className="btn btn-danger"
//                 onClick={() => deleteTodo(todo.id)}
//               >
//                 <AiOutlineClose size={12} />
//               </button>
//             </div>
//             <div
//               ref={(ref) => (textInputRefs.current[todo.id] = ref)}
//               contentEditable={todo.isEditing ? 'true' : 'false'}
//               suppressContentEditableWarning={true}
//               style={{
//                 wordBreak: 'break-word',
//                 whiteSpace: 'pre-wrap',
//                 textAlign: 'center',
//                 display: 'flex',
//                 flexDirection: 'column',
//                 alignItems: 'center',
//                 justifyContent: 'center',
//                 height: '100%',
//               }}
//               className={todo.completed ? 'text-muted text-decoration-line-through' : ''}
//               onClick={() => startEditing(todo.id)}
//               onBlur={() => updateTodo(todo.id)}
//             >
//               {todo.taskname}
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default App;


//getting tasks from db for each user

import React, { useState, useRef, useEffect } from 'react';
import { AiOutlineEdit, AiOutlineCheck, AiOutlineClose } from 'react-icons/ai';
import { v4 as uuid } from 'uuid';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import './todo.css';
import jwt from 'jsonwebtoken';

interface Todo {
  id: string;
  taskname: string;
  completed: boolean;
  color: string;
  isEditing: boolean;
}

const getRandomColor = (): string => {
  return '#ffeeba'; // or any color code you prefer
};

const App: React.FC = () => {
  const navigate = useNavigate();
  const [todos, setTodos] = useState<Todo[]>([]);
  const [inputText, setInputText] = useState<string>('');

  const textInputRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  const fetchUserTodos = async () => {
    try {
      const token = localStorage.getItem('token');
      // axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

      if (token !== null) {
        // Decode the token   
        const decoded = jwt.decode(token);
        // Check if the decoding was successful
        if (decoded !== null && typeof decoded === 'object') {
          // Access user data from the decoded token  
          const userData = decoded.userData;
          console.log('User Data:', userData);
        } else {
          console.error('Error decoding token');
        }
      } else {
        console.error('Token not found in local storage');
      }
      const response = await axios.get('http://localhost:4561/api/todo');

      if (response.status === 200) {
        setTodos(response.data);
      } else {
        console.error('Error fetching todos: Unexpected server response');
      }
    } catch (error) {
      console.error('Error fetching todos:', error);
    }
  };
  useEffect(() => {
    fetchUserTodos();
  }, []);

  const addTodo = async () => {
    if (inputText.trim() !== '') {
      const newTodo: Todo = {
        id: uuid(),
        taskname: inputText,
        completed: false,
        color: getRandomColor(), // Set the random color
        isEditing: false,
      };

      try {
        // Send the new todo to the MongoDB API
        const response = await axios.post('http://localhost:4561/api/todo', newTodo);

        if (response.status === 201) {
          // Assuming your server returns a specific status for successful todo creation
          setTodos((prevTodos) => [...prevTodos, newTodo]);
          setInputText('');
        } else {
          // Handle unsuccessful todo creation (e.g., display an error message)
          console.error('Error adding todo: Unexpected server response');
        }
      } catch (error) {
        // Handle network or server errors
        console.error('Error adding todo:', error);
        // You can show an error message to the user or perform other error-handling tasks
      }
    }
  };

  const startEditing = (id: string) => {
    setTodos((prevTodos) =>
      prevTodos.map((todo) =>
        todo.id === id ? { ...todo, isEditing: true } : todo
      )
    );
  };

  const updateTodo = (id: string) => {
    setTodos((prevTodos) =>
      prevTodos.map((todo) =>
        todo.id === id ? { ...todo, isEditing: false } : todo
      )
    );
  };

  const deleteTodo = (id: string) => {
    setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== id));
  };

  const signOut = () => {
    // Remove the token from local storage and set Authorization header to null
    localStorage.removeItem('token');
    axios.defaults.headers.common['Authorization'] = null;

    // Navigate to the home page or any desired location
    navigate('/');
  };

  useEffect(() => {
    todos.forEach((todo) => {
      if (todo.isEditing && textInputRefs.current[todo.id]) {
        textInputRefs.current[todo.id]?.focus();
      }
    });
  }, [todos]);

  return (
    <div className="container mt-5">
      <div className="d-flex justify-content-end mb-2">
        <Link to="/" className="btn btn-link" onClick={signOut}>
          Sign Out
        </Link>
      </div>
      <h1 className="text-center mb-4">Todo App</h1>
      <div className="mb-3 d-flex">
        <input
          type="text"
          className="form-control flex-grow-1"
          placeholder="Enter a task"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
        />
        <button className="btn btn-primary ms-2" onClick={addTodo}>
          Add Todo
        </button>
      </div>
      <div className="d-flex flex-wrap">
        {todos.map((todo) => (
          <div
            key={todo.id}
            className={`p-3 m-2 sticky-note ${todo.completed ? 'text-muted' : 'text-dark'}`}
          >
            <div className="btn-group" style={{ position: 'absolute', bottom: '5px', right: '5px' }}>
              <button
                className="btn btn-warning"
                onClick={() => startEditing(todo.id)}
              >
                <AiOutlineEdit size={16} />
              </button>
              <button
                className="btn btn-success"
                onClick={() => updateTodo(todo.id)}
              >
                <AiOutlineCheck size={16} />
              </button>
              <button
                className="btn btn-danger"
                onClick={() => deleteTodo(todo.id)}
              >
                <AiOutlineClose size={12} />
              </button>
            </div>
            <div
              ref={(ref) => (textInputRefs.current[todo.id] = ref)}
              contentEditable={todo.isEditing ? 'true' : 'false'}
              suppressContentEditableWarning={true}
              style={{
                wordBreak: 'break-word',
                whiteSpace: 'pre-wrap',
                textAlign: 'center',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                height: '100%',
              }}
              className={todo.completed ? 'text-muted text-decoration-line-through' : ''}
              onClick={() => startEditing(todo.id)}
              onBlur={() => updateTodo(todo.id)}
            >
              {todo.taskname}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;